package com.alipay.container.aop;

import com.alipay.util.LogUtil;
import java.lang.reflect.Method;
import java.util.logging.Logger;

/**
 * Created by duyl on 2019/8/31.
 */
public class UserInfoCheckInvocation implements MethodInvocation {

  private static Logger LOGGER = Logger.getLogger(UserInfoCheckInvocation.class.getName());

  private String METHOD_BUY = "buy";
  private String NO_LOGIN_USER = "no_login";

  private Object proxy;
  private Method method;
  private Object[] args;

  public UserInfoCheckInvocation(Object proxy, Method method, Object[] args) {
    this.proxy = proxy;
    this.method = method;
    this.args = args;
  }

  @Override
  public Object process() {
    if (method == null || args == null || args.length == 0) {
      return true;
    }
    if (!METHOD_BUY.equals(method.getName())) {
      return true;
    }

    if (args[0] instanceof String) {
      String userName = (String) args[0];
      if (userName.startsWith(NO_LOGIN_USER)) {
        LogUtil.warn(LOGGER, "游客" + userName + "未登陆，不允许购买");
        return false;
      }
    }

    return true;
  }

  @Override
  public Method getMethod() {
    return method;
  }

  @Override
  public Object[] getArguments() {
    return args;
  }
}
