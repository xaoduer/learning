package com.alipay.execption;

/**
 * Created by duyl on 2019/8/31.
 */
public class ServiceRuntimeException extends RuntimeException {

  public ServiceRuntimeException() {
  }

  public ServiceRuntimeException(String message) {
    super(message);
  }

  public ServiceRuntimeException(String message, Throwable cause) {
    super(message, cause);
  }

}
