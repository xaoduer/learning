/**
 * Alipay.com Inc.
 * Copyright (c) 2004-2019 All Rights Reserved.
 */
package com.alipay.container;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 简单服务容器
 *
 * @author dalong.wdl
 * @version $Id: DefaultContainer.java, v 0.1 2019年08月29日 10:03 AM dalong.wdl Exp $
 */
public class DefaultContainer implements Container {
    private static Logger LOGGER = Logger.getLogger(DefaultContainer.class.getName());

    private String             resourceName = "";
    private Map<Class, Object> localCache   = new HashMap<Class, Object>();

    private static Container ins;

    public DefaultContainer(String configResource) {
        this.resourceName = configResource;

        ins = this;
    }

    @Override
    public <T> T getBean(String beanId) {
        return null;
    }

    @Override
    public <T> T getBean(Class<T> clazz) {
        if (localCache.containsKey(clazz)) {
            return (T) localCache.get(clazz);
        }

        if (!clazz.isInterface()) {
            try {
                localCache.put(clazz, clazz.newInstance());
                return (T) localCache.get(clazz);
            } catch (Exception e) {
                LOGGER.log(Level.FINEST, e.getMessage(), e);
            }
        }

        return null;
    }

    public static Container getInstance() {
        return ins;
    }

}