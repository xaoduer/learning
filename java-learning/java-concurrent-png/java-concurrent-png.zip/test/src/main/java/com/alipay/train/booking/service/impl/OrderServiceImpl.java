/**
 * Alipay.com Inc.
 * Copyright (c) 2004-2019 All Rights Reserved.
 */
package com.alipay.train.booking.service.impl;

import com.alipay.container.DefaultContainer;
import com.alipay.container.annotation.ServiceProvider;
import com.alipay.container.annotation.ServiceReference;
import com.alipay.memdb.MemDB;
import com.alipay.memdb.SimpleDB;
import com.alipay.train.booking.model.BookingOrder;
import com.alipay.train.booking.model.enums.OrderStatus;
import com.alipay.train.booking.service.OrderService;
import com.alipay.train.booking.service.interceptor.UserInfoCheck;

import java.util.List;

/**
 *
 * @author dalong.wdl
 * @version $Id: OrderServiceImpl.java, v 0.1 2019年08月29日 9:46 AM dalong.wdl Exp $
 */
@ServiceProvider(id = "orderService", aop = UserInfoCheck.class)
public class OrderServiceImpl implements OrderService {

    @ServiceReference(ref = "simple_db")
    private MemDB db = DefaultContainer.getInstance().getBean(SimpleDB.class);

    private int i = 0;

    @Override
    public BookingOrder buy(String userName, int ticketCount) {
        BookingOrder order = new BookingOrder();

        order.setOrderNo("biz_" + System.currentTimeMillis() + "_" + userName + "_" + i++);
        order.setUserName(userName);
        order.setTicketCount(ticketCount);
        order.setStatus(OrderStatus.BOOKING_OK);

        db.insert(order.getOrderNo(), order);

        return order;
    }

    @Override
    public boolean unbuy(String orderNo) {

        db.remove(orderNo);

        return false;
    }

    @Override
    public List<BookingOrder> listBookingOrder(int pageNo, int pageSize) {
        return null;
    }
}