/**
 * Alipay.com Inc.
 * Copyright (c) 2004-2019 All Rights Reserved.
 */
package com.alipay.train.booking.service.impl;

import com.alipay.container.DefaultContainer;
import com.alipay.container.annotation.ServiceProvider;
import com.alipay.container.annotation.ServiceReference;
import com.alipay.memdb.MemDB;
import com.alipay.memdb.SimpleDB;
import com.alipay.memdb.StockDB;
import com.alipay.memdb.StockDBImpl;
import com.alipay.train.booking.model.BookingOrder;
import com.alipay.train.booking.model.enums.OrderStatus;
import com.alipay.train.booking.service.OrderService;
import com.alipay.train.booking.service.interceptor.UserInfoCheck;

import com.alipay.util.LogUtil;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * @author dalong.wdl
 * @version $Id: OrderServiceImpl.java, v 0.1 2019年08月29日 9:46 AM dalong.wdl Exp $
 */
@ServiceProvider(id = "orderService", aop = UserInfoCheck.class)
public class OrderServiceImpl implements OrderService {

  private static Logger LOGGER = Logger.getLogger(OrderServiceImpl.class.getName());

  //记录用户是否有退票记录
  private final Set<String> userUnbuy = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
  //记录用户当前是否存在有效订单
  private final Set<String> userBuy = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());

  @ServiceReference(ref = "simple_db")
  private MemDB db = DefaultContainer.getInstance().getBean(SimpleDB.class);

  //库存管理
  @ServiceReference(ref = "stock_db")
  private StockDB stockDB = DefaultContainer.getInstance().getBean(StockDBImpl.class);

  private int i = 0;

  @Override
  public BookingOrder buy(String userName, int ticketCount) {
    if (userBuy.contains(userName)) {
      LogUtil.warn(LOGGER, "用户" + userName + "已经购有订单存在，不允许再次购票");
      return null;
    }
    if (stockDB.decre(StockDBImpl.TICKET_NUMBER_KEY, ticketCount)) {
      LogUtil.warn(LOGGER, "当前票次已售完");
      return null;
    }

    BookingOrder order = new BookingOrder();
    order.setOrderNo("biz_" + userName + "_" + System.currentTimeMillis() + "_" + i++);
    order.setUserName(userName);
    order.setTicketCount(ticketCount);
    order.setStatus(OrderStatus.BOOKING_OK);

    try {
      db.insert(order.getOrderNo(), order);
      db.commit();
      userBuy.add(userName);
      return order;
    } catch (Exception e) {
      LogUtil.error(LOGGER, e, "用户购买异常");
    }
    return null;
  }

  @Override
  public boolean unbuy(String orderNo) {
    try {

      BookingOrder order = db.getObject(orderNo);
      String userName = order.getUserName();
      if (userUnbuy.contains(userName)) {
        LogUtil.warn(LOGGER, "用户" + userName + "已经退票一次，不允许再次退票");
        return false;
      }

//    List<BookingOrder> userOrders = db.scan("biz_" + userName, 3);
//    if (userOrders != null && userOrders.size() > 0) {
//      for (BookingOrder userOrder : userOrders) {
//        if (userOrder.getStatus() == OrderStatus.BOOKING_UNDO) {
//          LogUtil.warn(LOGGER, "用户" + userName + "已经退票一次，不允许再次退票");
//          return false;
//        }
//      }
//    }

      if (order.getStatus() == OrderStatus.BOOKING_OK) {
        order.setStatus(OrderStatus.BOOKING_UNDO);
        db.update(orderNo, order);
        db.commit();
        stockDB.incre(StockDBImpl.TICKET_NUMBER_KEY, order.getTicketCount());
        userUnbuy.add(userName);
        userBuy.remove(userName);
        return true;
      }
    } catch (Exception e) {
      LogUtil.error(LOGGER, e, "用户退票异常");
    }
    return false;
  }

  @Override
  public List<BookingOrder> listBookingOrder(int pageNo, int pageSize) {
    return null;
  }
}