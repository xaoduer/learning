/**
 * Alipay.com Inc.
 * Copyright (c) 2004-2019 All Rights Reserved.
 */
package com.alipay.memdb;

/**
 *
 * @author dalong.wdl
 * @version $Id: DBStorage.java, v 0.1 2019年08月29日 10:20 AM dalong.wdl Exp $
 */
public class DBStorage {
}