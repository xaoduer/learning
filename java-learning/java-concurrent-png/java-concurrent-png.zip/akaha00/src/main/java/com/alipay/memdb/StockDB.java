package com.alipay.memdb;

/**
 * Created by duyl on 2019/8/31.
 */
public interface StockDB {

  /**
   * 库存初始化
   */
  boolean init(String key, Long capacity);

  /**
   * 增加库存
   */
  boolean incre(String key, int count);


  /**
   * 去库存
   */
  boolean decre(String key, int count);

}
