/**
 * Alipay.com Inc.
 * Copyright (c) 2004-2019 All Rights Reserved.
 */
package com.alipay.memdb;

import com.alipay.util.LogUtil;
import com.alipay.util.RandomUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 */
public class StockDBImpl implements StockDB {

  public final static String TICKET_NUMBER_KEY = "ticket_number";
  private Map<String, Long> data = new ConcurrentHashMap<String, Long>();


  @Override
  public boolean init(String key, Long capacity) {
    data.put(key, capacity);
    return true;
  }

  @Override
  public boolean incre(String key, int count) {
    data.put(key, data.get(key) + count);
    return true;
  }

  @Override
  public boolean decre(String key, int count) {
    long totalCount = data.get(key) - count;
    if (totalCount < 1) {
      return false;
    }
    data.put(key, totalCount);
    return true;
  }
}