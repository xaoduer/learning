/**
 * Alipay.com Inc.
 * Copyright (c) 2004-2019 All Rights Reserved.
 */
package com.alipay.container;

import com.alipay.container.annotation.ServiceProvider;
import com.alipay.container.aop.MethodInterceptor;
import com.alipay.container.proxy.OrderServiceInvocationHandler;
import com.alipay.execption.ServiceRuntimeException;
import com.alipay.util.LogUtil;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 简单服务容器
 *
 * @author dalong.wdl
 * @version $Id: DefaultContainer.java, v 0.1 2019年08月29日 10:03 AM dalong.wdl Exp $
 */
public class DefaultContainer implements Container {

  private static Logger LOGGER = Logger.getLogger(DefaultContainer.class.getName());

  private String resourceName = "";
  private Map<Class, Object> localCache = new ConcurrentHashMap<Class, Object>();

  private static Container ins;

  public DefaultContainer(String configResource) {
    this.resourceName = configResource;

    ins = this;
  }

  @Override
  public <T> T getBean(String beanId) {
    return null;
  }

  @Override
  public <T> T getBean(Class<T> clazz) {
    if (clazz == null) {
      return null;
    }
    try {
      if (localCache.containsKey(clazz)) {
        return (T) localCache.get(clazz);
      }
      if (!clazz.isInterface()) {
        Object target = clazz.newInstance();
        if (target == null) {
          LogUtil.warn(LOGGER, "target is null ...");
          return null;
        }

        ServiceProvider serviceProvider = clazz.getAnnotation(ServiceProvider.class);
        if (serviceProvider != null) {
          Class<? extends MethodInterceptor> methodInterceptorClazz = serviceProvider.aop();
          if (methodInterceptorClazz != null && !methodInterceptorClazz.isInterface()) {
            MethodInterceptor methodInterceptor = methodInterceptorClazz.newInstance();
            if (methodInterceptor != null) {
              target = Proxy.newProxyInstance(target.getClass().getClassLoader(), target.getClass().getInterfaces(), new
                  OrderServiceInvocationHandler(target, methodInterceptor));
            }
          }
        }

        localCache.put(clazz, target);
        return (T) target;
      }
    } catch (Exception e) {
      LOGGER.log(Level.FINEST, e.getMessage(), e);
    }

    return null;
  }

  public static Container getInstance() {
    return ins;
  }

}