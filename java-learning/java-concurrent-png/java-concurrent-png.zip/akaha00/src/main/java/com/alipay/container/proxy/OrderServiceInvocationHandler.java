package com.alipay.container.proxy;

import com.alipay.container.aop.MethodInterceptor;
import com.alipay.container.aop.MethodInvocation;
import com.alipay.container.aop.UserInfoCheckInvocation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * Created by duyl on 2019/8/31.
 */
public class OrderServiceInvocationHandler implements InvocationHandler {


  private Object target;
  private MethodInterceptor methodInterceptor;

  public OrderServiceInvocationHandler(Object target, MethodInterceptor methodInterceptor) {
    this.target = target;
    this.methodInterceptor = methodInterceptor;
  }

  @Override
  public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
    MethodInvocation methodInvocation = new UserInfoCheckInvocation(proxy, method, args);
    Boolean success = (Boolean) methodInterceptor.invoke(methodInvocation);
    if (!success) {
      return null;
    }
    if (method != null) {
      return method.invoke(target, args);
    }
    return null;

  }
}
